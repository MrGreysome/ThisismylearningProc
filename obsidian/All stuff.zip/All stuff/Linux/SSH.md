```ssh-keygen``` - generate private and public keys for ssh
