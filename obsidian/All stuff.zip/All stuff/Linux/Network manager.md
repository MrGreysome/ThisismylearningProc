```ifconfig eth0 hw ether 88:88:88:88:88:88``` - changing MAC address using ifconfig, macchanger 
TMAC - for windows 

#### netools 
```netstat -lp``` - port listen
```netstat -an``` - connected port

```ss -lntp``` - listen ports without netrools 

```arp -a``` - address resolution protocol, -i specify interface, -d remove address, -v verbose

