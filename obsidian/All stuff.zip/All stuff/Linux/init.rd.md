/etc/init.d/ - startup and shutdowns scripts, old linux

