vurln scanner with yaml templates  
get from git nuclei and nuclei-templates  
`nuclei -v -l alivehttp.txt -t /templates/location -o out.txt`