webcam
hostname:somerand.site
product:""Apache Tomcat""
org: ""Some  Corp name""
ssl:somerand.site
port:443