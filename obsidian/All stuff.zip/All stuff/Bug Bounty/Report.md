## Key factors
- Report should be simple, clear and understandable
- Presentation of the report is also important
- The report should be well organized
- Correct spelling and grammar is important too
- Always make sure that you use a consistent voice and style in writing a report
- Perform a detailed analysis of the vulnerability to find out its root cause

## Types of report
- Executive Class Report
- Management Class Report
- Developer Report

