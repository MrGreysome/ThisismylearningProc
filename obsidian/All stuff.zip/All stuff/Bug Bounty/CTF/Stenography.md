exiftool - to extract metadata from file, for examples images from site
https://exiftool.org/

hexdump - metadata from file, but in hex

