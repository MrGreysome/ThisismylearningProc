Example
site:gm.com -s-""search-careers"" -www ext:php,zip...
-www inurl:login,dev.... -tmsii
-www title:login, intitle:admin

https://ahrefs.com/blog/google-advanced-search-operators/