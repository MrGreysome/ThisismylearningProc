webdata extractor - pulling all data available on web page
http://www.webextractor.com/

httrack - website copy
