Example
https://example.com/login/?nextPage=https://google.com
(could allowed but your own redirect isn't you could add google.com@somerand.com)