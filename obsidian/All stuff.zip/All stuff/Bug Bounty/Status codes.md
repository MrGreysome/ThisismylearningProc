200 Successful responce
300 Redirects
400
401 Unauthorized or unauthenticated
403 Forbidden or no access to resources
404 Not found or file does not exist
405 Http method not allowed
500 Internal error where server does not know how to handle request

302 often is for [[Open redirect]]
