Cros site request forgery
https://github.com/swisskyrepo/PayloadsAllTheThings