Whois,buildwith, crunchbase, webarchive(wayback machine)

==Information gathering==
- Analyze robots.txt
- Search engines
- Indetify entry points
- Web Applications
- Analysis of error codes
- Recognized file types
- Examine source page
- Services fingerprint
- Informantion gatharing tools
- Server side technology
- Domains and subdomains
- Document everything

==Authentication testing==
- Test for vurlnrable passwords
- Logout and clear browser cache
- CAPTCHA
- Multiple factors
- Race conditions
- Document everything

==wappalazer==
Identify software on website