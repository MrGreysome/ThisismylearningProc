Insecure direct object reference
Swapping id's
https://somesite.com/setting/112 change to 1