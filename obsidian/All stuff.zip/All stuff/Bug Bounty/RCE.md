Remote code execution
Could be run on web page when you could send some info with application on server
or some popular too add to web site, ```id=1; ls, id, pwd``` or ```& | ls, etc...```
Some time could run PHP code or other backend language 
Example in comments section, PHP shell exec
```<?PHP phpinfo(); ?>```